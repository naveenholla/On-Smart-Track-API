# Paper Trading Snapshot

Only for papertrading, since it scrapes the virtual brokers
attributes.

## Through AutoTrader

```python
from autotrader import AutoTrader

AutoTrader.papertrade_snapshot('picklename')
```

[ example output ]




## Command Line Tool

```
autotrader snapshot PICKLEFILE
```

