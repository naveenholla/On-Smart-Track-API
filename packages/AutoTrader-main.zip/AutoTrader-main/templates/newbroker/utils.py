from autotrader.brokers.broker_utils import BrokerUtils


class Utils(BrokerUtils):
    def __init__(self, **kwargs):
        pass

    def __repr__(self):
        return "AutoTrader Broker Utilities"

    def __str__(self):
        return "AutoTrader Broker Utilities"
