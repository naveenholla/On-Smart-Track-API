# License

```{include} ../../LICENSE
```