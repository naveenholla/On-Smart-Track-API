```{include} ../../CHANGELOG.md
```

```{toctree}
:maxdepth: 2
:hidden:

Older versions <old-changelog>
```