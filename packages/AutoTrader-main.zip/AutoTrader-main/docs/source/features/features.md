(features-landing)=
# AutoTrader Features

AutoTrader is feature rich, with everything you need to go from concept to livetrading. Use the links 
below to see some of the features AutoTrader has to show for.

```{toctree}
:maxdepth: 1

Backtesting <backtesting>
Interactive Visualisations <visualisation>
Live Trading <live-trading>
Data Pipelines <data-feeds>
Custom Indicators <indicators>
```

